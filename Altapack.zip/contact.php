﻿<?php
if(isset($_GET['email'])) {
	if(!isset($_GET['name']) ||
	!isset($_GET['email']) ||
	!isset($_GET['subject']) ||
	!isset($_GET['message'])) {
		echo "<b>Ocurrió un error y el formulario no ha sido enviado. </b><br />";
		echo "Por favor, vuelva atrás y verifique la información ingresada<br />";
		die();
	}
	$subject = "Contacto Formulario";
	$name = 'Compañia';
	$message   = '
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" /> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#f5f5f5">
  <tr>
    <td>
<table align="center" bgcolor="#f5f5f5">
      <tr>
    <td width="640" class="container">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td width="70" valign="bottom"><div style="height:127px"><img src="http://altapack.viesagroup.com/img-email/logo.png" width="120" border="0" alt="Margen IT" style="display:block; color:#333333; font-family:Helvetica Neue Light, Helvetica Neue Regular, Helvetica, Arial; font-size:10px;"></div></td>
        <td width="570" valign="middle" style="padding-bottom:5px"><div align="right"><font style="font-size:11px; -webkit-text-size-adjust:none; line-height:16px" face="Helvetica Neue Light, Helvetica Neue Regular, Helvetica, Arial" color="#666666">Correo de notificaci&oacute;n por llenado de formulario.<br>
        </font></div></td>
      </tr>
    </table>
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#006287">
<tr>
<td align="left" style="padding:30px"><font style="font-size:40px" color="#ffffff" face="Helvetica Neue Light, Helvetica Neue Regular, Helvetica, Arial">Notificaci&oacute;n de formulario de contacto</font></td>
</tr>

<tr>
<td align="left" valign="top" bgcolor="#ffffff" style="line-height:16px"><div style="height:16px"><img src="http://altapack.viesagroup.com/img-email/flecha.png" border="0" width="60" height="16" style="display:block"></div></td>
</tr>

          <tr>
           <td width="100%" align="left" style="padding:20px" bgcolor="#ffffff">
     <font style="font-size:14px; line-height:20px" face="Helvetica Neue Regular, Helvetica, Arial" color="#666666">A quien corresponda:<br><br>
   </font>
         	
            
     		
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        	<tr>
                <td>
                    <pre style="font-size:14px; line-height:1.5; font-weight:bold; font-family:Helvetica Neue Regular, Helvetica, Arial; color:#666666">Nombre:</pre>
               </td>
                <td>
                     <font style="font-size:14px; line-height:20px" face="Helvetica Neue Regular, Helvetica, Arial" color="#666666">
                        ' . utf8_decode ($_GET['name']) . '
                    </font>
               </td>
          </tr>
        	<tr>
                <td>
                    <pre style="font-size:14px; line-height:1.5; font-weight:bold; font-family:Helvetica Neue Regular, Helvetica, Arial; color:#666666">Email:</pre>
               </td>
                <td>
                     <font style="font-size:14px; line-height:20px" face="Helvetica Neue Regular, Helvetica, Arial" color="#666666">
                        ' . utf8_decode ($_GET['email']) . '
                    </font>
               </td>
          </tr>
        	<tr>
                <td>
                    <pre style="font-size:14px; line-height:1.5; font-weight:bold; font-family:Helvetica Neue Regular, Helvetica, Arial; color:#666666">Asunto:</pre>
               </td>
                <td>
                     <font style="font-size:14px; line-height:20px" face="Helvetica Neue Regular, Helvetica, Arial" color="#666666">
                        ' . $_GET['subject'] . '
                    </font>
               </td>
          </tr>
        	<tr>
                <td>
                    <pre style="font-size:14px; line-height:1.5; font-weight:bold; font-family:Helvetica Neue Regular, Helvetica, Arial; color:#666666">Mensaje:</pre>
               </td>
                <td>
                     <font style=" font-size:14px; line-height:20px" face="Helvetica Neue Regular, Helvetica, Arial" color="#666666">
                        ' . $_GET['message'] . '
                    </font>
               </td>
          </tr>
        </table>
           </td>
          </tr>
        </table>
		
 												<table border="0" align="center" cellspacing="0" cellpadding="0" class="container-table" style="width: 470px;">
                                                    <tbody>
                                                        <tr>
                                                            <td height="35" colspan="11">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="18" valign="top"><a href="https://www.facebook.com/pages/Margen-It/624903480949491"><img border="0" style="display: block;" src="http://benchmarkemail.com/images/event/emails/footer-fb.png" alt="Facebook" /></a></td>
                                                            <td width="54">&nbsp;</td>
                                                            <td width="46" valign="top"><a href="https://twitter.com/Margen_It"><img border="0" style="display: block;" src="http://benchmarkemail.com/images/event/emails/footer-tw.png" alt="Twitter" /></a></td>
                                                          	<td width="53">&nbsp;</td>
                                                            <td width="35" valign="top"><a href="http://instagram.com/"><img border="0" style="display: block;" src="http://benchmarkemail.com/images/event/emails/footer-ig.png" alt="Instagram" /></a></td>
                                                            <td width="53">&nbsp;</td>
                                                            <td width="40" valign="top"><a href="mailto:hola@margenit.com"><img border="0" style="display: block;" src="http://benchmarkemail.com/images/event/emails/footer-email.png" alt="Email" /></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td height="35" colspan="11">&nbsp;</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
												
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" style="padding-top:20px" id="footer"><font style="font-size:10px;-webkit-text-size-adjust:none;" face="Arial, Helvetica, sans-serif" color="#999999">Por favor, no respondas a este correo electr&oacute;nico. Los correos electr&oacute;nicos enviados a esta direcci&oacute;n no se responder&aacute;n.</font></td>
          </tr>
        </table>
		</td>
  </tr>
</table>
</td>
  </tr>
</table>
	';
	$Header = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$Header .= 'From: Contacto <formulario@viesagroup.com>' ."\r\n";
        /*   */
	@mail(" ventas@altapack.com, administracion@viesagroup.com", $subject, $message, $Header);
	echo "¡El mensaje se ha enviado con éxito!";
}
?>